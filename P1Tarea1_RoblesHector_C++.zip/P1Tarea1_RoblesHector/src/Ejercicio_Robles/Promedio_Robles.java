package Ejercicio_Robles; // package donde se encuentra la clase.

import java.io.FileWriter; // escribir en archivos.
import java.io.IOException; // manejar errores de entrada/salida.
import java.util.InputMismatchException; // manejar errores de entrada.
import java.util.Scanner; // leer la entrada del usuario.

public class Promedio_Robles {

    private float num1 = -1, num2 = -1, num3 = -1; // Inicializa notas con valores inválidos
    private float promedio; // Variable para almacenar el promedio de las notas.
    private String nombre; // Variable para almacenar el nombre del usuario.

    public static void main(String[] args) {
        Promedio_Robles programa = new Promedio_Robles(); // Crea una instancia de la clase.
        programa.iniciar(); // Llama al metodo iniciar para ejecutar el programa.
    }

    private void iniciar() {
        Scanner scanner = new Scanner(System.in); // Objeto Scanner para leer la entrada del usuario.
        int opcion; // Variable para almacenar la opcion del menu

        System.out.println("Bienvenido"); // Muestra un mensaje de bienvenida
        
        // Bucle que solicita el nombre hasta que solo contenga letras
        do {
            System.out.print("Por favor, ingresa tu nombre: "); // Solicita ingresar el nombre
            nombre = scanner.nextLine(); // Almacena el nombre ingresado
            if (!nombre.matches("[a-zA-Z ]+")) { // Verifica que solo contenga letras y espacios
                System.out.println("Nombre no válido. Solo se permiten letras y espacios.");
            }
        } while (!nombre.matches("[a-zA-Z ]+")); // Repite hasta que el nombre sea valido

        // Bucle para mostrar el menu y ejecutar la opcion seleccionada
        do {
            mostrarMenu(); // Llama al metodo para mostrar el menu
            opcion = leerOpcion(scanner); // Lee la opción seleccionada

            // Ejecuta la opcion seleccionada
            switch (opcion) {
                case 1 -> ingresarNotas(scanner); // Llama a ingresar notas si la opción es 1
                case 2 -> {
                    if (num1 != -1 && num2 != -1 && num3 != -1) { // Verifica que las notas hayan sido ingresadas
                        calcularPromedio(); // Llama al metodo para calcular el promedio
                    } else {
                        System.out.println("Debes ingresar todas las notas antes de calcular el promedio.");
                    }
                }
                case 3 -> System.out.println("Saliendo del programa..."); // Muestra un mensaje de salida
                default -> System.out.println("Opción inválida, intenta de nuevo."); // Mensaje de error si la opción no es valida
            }
        } while (opcion != 3); // Repite el menu mientras la opcion no sea salir

        scanner.close(); // Cierra el objeto Scanner
    }

    private void mostrarMenu() {
        System.out.println("\nMenu:"); // Muestra el titulo del menu
        System.out.println("1. Ingresar notas"); // Opcion para ingresar notas
        System.out.println("2. Calcular promedio y guardar en archivo"); // Opcion para calcular y guardar el promedio
        System.out.println("3. Salir"); // Opcion para salir del programa
        System.out.print("Seleccione una opción: "); // Solicita al usuario elegir una opcion
    }

    private int leerOpcion(Scanner scanner) {
        int opcion = -1; // Inicializa la opcion con un valor invalido
        try {
            opcion = scanner.nextInt(); // Lee un numero entero ingresado por el usuario
        } catch (InputMismatchException e) {
            System.out.println("Entrada no válida, ingrese solo números."); // Muestra un mensaje de error si la entrada no es un numero
            scanner.next(); // Limpia el buffer de entrada
        }
        return opcion; // Retorna la opcion ingresada
    }

    private void ingresarNotas(Scanner scanner) {
        num1 = leerNota(scanner, 1); // Llama a leerNota para la primera nota
        num2 = leerNota(scanner, 2); // Llama a leerNota para la segunda nota
        num3 = leerNota(scanner, 3); // Llama a leerNota para la tercera nota
    }

    private float leerNota(Scanner scanner, int numeroNota) {
        float nota = -1; // Inicializa la nota con un valor invalido
        while (nota < 0 || nota > 20) { // Repite hasta que la nota este en el rango
            System.out.printf("Ingresa la nota %d (entre 0 y 20): ", numeroNota); // Solicita ingresar la nota
            try {
                nota = scanner.nextFloat(); // Lee un numero decimal ingresado por el usuario
                if (nota < 0 || nota > 20) {
                    System.out.println("Nota fuera del rango permitido. Intenta de nuevo."); // Mensaje si la nota esta fuera del rango
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Ingrese un número entre 0 y 20."); // Muestra un mensaje si la entrada no es un numero
                scanner.next(); // Limpia el buffer de entrada
            }
        }
        return nota; // Retorna la nota valida
    }

    private void calcularPromedio() {
        promedio = (num1 + num2 + num3) / 3; // Calcula el promedio de las tres notas
        System.out.printf("Promedio calculado: %.2f%n", promedio); // Muestra el promedio calculado
        guardarEnArchivo(); // Llama al metodo para guardar los datos en el archivo
    }

    private void guardarEnArchivo() {
        try (FileWriter archivo = new FileWriter("notas_promedio.txt", true)) { // Crea el archivo en modo de agregar
            archivo.write("Nombre: " + nombre + "\n"); // Escribe el nombre en el archivo
            archivo.write("Notas: " + num1 + ", " + num2 + ", " + num3 + "\n"); // Escribe las notas en el archivo
            archivo.write("Promedio: " + promedio + "\n\n"); // Escribe el promedio en el archivo
            System.out.println("Datos guardados en 'notas_promedio.txt'."); // mensaje de confirmacion de guardado
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage()); // Mensaje de error al escribir en el archivo
        }
    }
}