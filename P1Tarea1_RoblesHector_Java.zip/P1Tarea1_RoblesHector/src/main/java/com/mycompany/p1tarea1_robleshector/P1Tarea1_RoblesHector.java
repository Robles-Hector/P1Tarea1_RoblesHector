package com.mycompany.p1tarea1_robleshector;

import java.io.FileWriter; // escribir en archivos
import java.io.IOException; // manejar errores de entrada/salida
import java.util.InputMismatchException; // manejar errores de entrada
import java.util.Scanner; // leer la entrada del usuario
import org.json.simple.JSONObject; // crear archivos JSON
import org.json.simple.JSONArray; // manejar arrays en JSON
import com.opencsv.CSVWriter; // crear archivos CSV
import java.io.File;

public class P1Tarea1_RoblesHector {

    private float num1 = -1, num2 = -1, num3 = -1; // Inicializa notas con valores invalidos
    private float promedio; // Variable para almacenar el promedio de las notas
    private String nombre; // Variable para almacenar el nombre del usuario

    public static void main(String[] args) {
        P1Tarea1_RoblesHector programa = new P1Tarea1_RoblesHector(); // Crea una instancia de la clase
        programa.iniciar(); // Llama al metodo iniciar para ejecutar el programa
        
    }

    private void iniciar() {
        Scanner scanner = new Scanner(System.in); // Objeto Scanner para leer la entrada del usuario
        int opcion; // Variable para almacenar la opcion del menu

        System.out.println("Bienvenido");

        // Bucle que solicita el nombre hasta que solo contenga letras
        do {
            System.out.print("Por favor, ingresa tu nombre: ");
            nombre = scanner.nextLine();
            if (!nombre.matches("[a-zA-Z ]+")) {
                System.out.println("Nombre no valido. Solo se permiten letras y espacios.");
            }
        } while (!nombre.matches("[a-zA-Z ]+"));

        // Bucle para mostrar el menu y ejecutar la opcion seleccionada
        do {
            mostrarMenu();
            opcion = leerOpcion(scanner);

            switch (opcion) {
                case 1 -> ingresarNotas(scanner);
                case 2 -> {
                    if (num1 != -1 && num2 != -1 && num3 != -1) {
                        calcularPromedio();
                    } else {
                        System.out.println("Debes ingresar todas las notas antes de calcular el promedio.");
                    }
                }
                case 3 -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Opcion invalida, intenta de nuevo.");
            }
        } while (opcion != 3);

        scanner.close();
    }

    private void mostrarMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Ingresar notas");
        System.out.println("2. Calcular promedio y guardar");
        System.out.println("3. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private int leerOpcion(Scanner scanner) {
        int opcion = -1;
        try {
            opcion = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Entrada no valida, ingrese solo numeros.");
            scanner.next();
        }
        return opcion;
    }

    private void ingresarNotas(Scanner scanner) {
        num1 = leerNota(scanner, 1);
        num2 = leerNota(scanner, 2);
        num3 = leerNota(scanner, 3);
    }

    private float leerNota(Scanner scanner, int numeroNota) {
        float nota = -1;
        while (nota < 0 || nota > 20) {
            System.out.printf("Ingresa la nota (entre 0 y 20) para la nota: ", numeroNota);
            try {
                nota = scanner.nextFloat();
                if (nota < 0 || nota > 20) {
                    System.out.println("Nota fuera del rango permitido. Intenta de nuevo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no valida. Ingrese un numero entre 0 y 20.");
                scanner.next();
            }
        }
        return nota;
    }

    private void calcularPromedio() {
        promedio = (num1 + num2 + num3) / 3;
        System.out.printf("Promedio calculado: ", promedio);

        if (promedio >= 14) {
            System.out.println("¡Felicidades! Has aprobado.");
        } else {
            System.out.println("Lamentablemente, has reprobado.");
        }

        guardarEnJson();
        guardarEnCsv();
    }

    private void guardarEnJson() {
        JSONObject datos = new JSONObject();
        datos.put("Nombre", nombre);

        // Almacena las notas en un array JSON
        JSONArray notas = new JSONArray();
        notas.add(num1);
        notas.add(num2);
        notas.add(num3);
        datos.put("Notas", notas);

        datos.put("Promedio", promedio);
        datos.put("Estado", promedio >= 14 ? "Aprobado" : "Reprobado");

        try (FileWriter archivoJson = new FileWriter("notas_promedio.json")) {
            archivoJson.write(datos.toJSONString());
            archivoJson.flush();
            System.out.println("Datos guardados en 'notas_promedio.json'.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo JSON: " + e.getMessage());
        }
    }

    private void guardarEnCsv() {
        File archivoCsv = new File("notas_promedio.csv");
        boolean archivoExiste = archivoCsv.exists();

        try (CSVWriter writer = new CSVWriter(new FileWriter(archivoCsv, true))) {
            if (!archivoExiste) {
                String[] encabezado = { "Nombre", "Nota1", "Nota2", "Nota3", "Promedio", "Estado" };
                writer.writeNext(encabezado);
            }
            String[] datos = { nombre, String.valueOf(num1), String.valueOf(num2), String.valueOf(num3),
                    String.valueOf(promedio), promedio >= 14 ? "Aprobado" : "Reprobado" };
            writer.writeNext(datos);
            System.out.println("Datos guardados en 'notas_promedio.csv'.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo CSV: " + e.getMessage());
        }
    }
}
